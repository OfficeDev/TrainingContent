// Default entry point for client scripts
// Automatically generated
// Please avoid from modifying to much...


// Added by generator-teams
export * from './teamsApp1TabConfig';
export * from './teamsApp1TabTab';
export * from './adminconsent';
export * from './auth';